package com.logic


object Firing {




}