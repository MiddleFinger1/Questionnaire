package com.json

interface JsonObject {

    fun toJsonObject(): String
}