package com.json.user

class AppConfig {

    var textColor = ""
    var textSizeTitle = 24f

    companion object {

        fun toJsonObject(){

        }

    }

}