package com.ui.game

data class Subject(
    val subject: String,
    val background: String,
    val path: String
)